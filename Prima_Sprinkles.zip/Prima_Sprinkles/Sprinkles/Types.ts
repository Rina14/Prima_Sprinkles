namespace Sprinkles {
  export enum TYPES {
    ORANGE = "orange",
    RED = "red",
    BLUE = "blue",
    GREEN = "green"
  }
}